function remove_ok(){
	if (document.remove_frm.u_pwd.value.length == 0) {
		alert("비밀번호를 입력하세요.");
		remove_frm.u_pwd.focus();
		return;
	}
	document.remove_frm.submit();
}