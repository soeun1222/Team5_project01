package team;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import myUtil.HanConv;

public class TeamBoardDBBean {
	private static TeamBoardDBBean instance=new TeamBoardDBBean();
	public static TeamBoardDBBean getInstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception {
		Context ctx=new InitialContext();
		DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	public ArrayList<TeamBoard> userListBoard(String pageNumber) {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		ResultSet pageSet=null;
		int dbCount=0;
		int absolutePage=1;
		
		ArrayList<TeamBoard> userList=new ArrayList<TeamBoard>();
		try {
			con = getConnection();
			stmt = con.createStatement();
			pageSet = stmt.executeQuery("select count(u_id) from user_tbl");
			
			if(pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
				stmt.close();
			}
			
			if(dbCount % TeamBoard.pageSize == 0) {
				TeamBoard.pageCount = dbCount / TeamBoard.pageSize;
			}else {
				TeamBoard.pageCount = dbCount / TeamBoard.pageSize + 1; //pageCount = ������ ����	
			}
			
			if(pageNumber != null) {
				TeamBoard.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (TeamBoard.pageNum-1) * TeamBoard.pageSize + 1;
			}
			
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			String sql="select * from user_tbl";
			rs=stmt.executeQuery(sql);
			
			if(rs.next()) {
				rs.absolute(absolutePage);
				int count = 0;
				while (count < TeamBoard.pageSize) {
					TeamBoard Board=new TeamBoard();
					Board.setU_id(rs.getString(1));
					Board.setU_pwd(rs.getString(2));
					Board.setU_name(rs.getString(3));
					Board.setU_email(rs.getString(4));
					Board.setU_phone(rs.getInt(5));
					Board.setU_birth(rs.getInt(6));
					Board.setU_sex(rs.getInt(7));
					
					userList.add(Board);
					
					if (rs.isLast()) {
						break;
					}else {
						rs.next();
					}
					count++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return userList;
	}
	
	public ArrayList<TeamBoard> nfListBoard(String pageNumber) {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		ResultSet pageSet=null;
		int dbCount=0;
		int absolutePage=1;
		
		ArrayList<TeamBoard> nfList=new ArrayList<TeamBoard>();
		
		try {
			con = getConnection();
			stmt = con.createStatement();
			pageSet = stmt.executeQuery("select count(nf_num) from non_face");
			
			if(pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
				stmt.close();
			}
			
			if(dbCount % TeamBoard.pageSize == 0) {
				TeamBoard.pageCount = dbCount / TeamBoard.pageSize;
			}else {
				TeamBoard.pageCount = dbCount / TeamBoard.pageSize + 1; //pageCount = ������ ����	
			}
			
			if(pageNumber != null) {
				TeamBoard.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (TeamBoard.pageNum-1) * TeamBoard.pageSize + 1;
			}
			
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			String sql="select * from non_face";
			rs=stmt.executeQuery(sql);
			
			if(rs.next()) {
				rs.absolute(absolutePage);
				int count = 0;
				while (count < TeamBoard.pageSize) {
					TeamBoard Board=new TeamBoard();
					Board.setNf_num(rs.getInt(1));
					Board.setNf_title(rs.getString(2));
					Board.setNf_content(rs.getString(3));
					Board.setNf_date(rs.getTimestamp(4));
					Board.setNf_hit(rs.getInt(5));
					
					nfList.add(Board);
					
					if (rs.isLast()) {
						break;
					}else {
						rs.next();
					}
					count++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return nfList;
	}
	
	public ArrayList<TeamBoard> htListBoard(String pageNumber) {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		ResultSet pageSet=null;
		int dbCount=0;
		int absolutePage=1;
		
		ArrayList<TeamBoard> htList=new ArrayList<TeamBoard>();
		
		try {
			con = getConnection();
			stmt = con.createStatement();
			pageSet = stmt.executeQuery("select count(ht_num) from home_tip");
			
			if(pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
				stmt.close();
			}
			
			if(dbCount % TeamBoard.pageSize == 0) {
				TeamBoard.pageCount = dbCount / TeamBoard.pageSize;
			}else {
				TeamBoard.pageCount = dbCount / TeamBoard.pageSize + 1; //pageCount = ������ ����	
			}
			
			if(pageNumber != null) {
				TeamBoard.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (TeamBoard.pageNum-1) * TeamBoard.pageSize + 1;
			}
			
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			String sql="select * from home_tip";
			rs=stmt.executeQuery(sql);
			
			if(rs.next()) {
				rs.absolute(absolutePage);
				int count = 0;
				while (count < TeamBoard.pageSize) {
					TeamBoard Board=new TeamBoard();
					Board.setHt_num(rs.getInt(1));
					Board.setHt_title(rs.getString(2));
					Board.setHt_content(rs.getString(3));
					Board.setHt_date(rs.getTimestamp(4));
					Board.setHt_hit(rs.getInt(5));
					
					htList.add(Board);
					if(rs.isLast()) {
						break;
					}else {
						rs.next();
					}
					count++;
				}				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return htList;
	}
	
	public ArrayList<TeamBoard> blListBoard(String pageNumber) {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		ResultSet pageSet=null;
		int dbCount=0;
		int absolutePage=1;
		
		ArrayList<TeamBoard> blList=new ArrayList<TeamBoard>();
		
		try {
			con = getConnection();
			stmt = con.createStatement();
			pageSet = stmt.executeQuery("select count(bl_num) from bucket_list");
			
			if(pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
				stmt.close();
			}
			
			if(dbCount % TeamBoard.pageSize == 0) {
				TeamBoard.pageCount = dbCount / TeamBoard.pageSize;
			}else {
				TeamBoard.pageCount = dbCount / TeamBoard.pageSize + 1; //pageCount = ������ ����	
			}
			
			if(pageNumber != null) {
				TeamBoard.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (TeamBoard.pageNum-1) * TeamBoard.pageSize + 1;
			}
			
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			String sql="select * from bucket_list";
			rs=stmt.executeQuery(sql);
			
			if(rs.next()) {
				rs.absolute(absolutePage);
				int count = 0;
				while (count < TeamBoard.pageSize) {
					TeamBoard Board=new TeamBoard();
					Board.setBl_num(rs.getInt(1));
					Board.setBl_title(rs.getString(2));
					Board.setBl_like(rs.getInt(3));
					
					blList.add(Board);
					
					if(rs.isLast()) {
						break;
					}else {
						rs.next();
					}
					count++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return blList;
	}
	
	public ArrayList<TeamBoard> commListBoard() {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		ArrayList<TeamBoard> commList=new ArrayList<TeamBoard>();
		
		try {
			con = getConnection();
			stmt = con.createStatement();
			String sql="select * from comment_tbl";
			rs=stmt.executeQuery(sql);
			
			while (rs.next()) {
				TeamBoard Board=new TeamBoard();
				Board.setComm_num(rs.getInt(1));
				Board.setComm_table(rs.getString(2));
				Board.setComm_content(rs.getString(3));
				
				commList.add(Board);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return commList;
	}
	
	public TeamBoard getBoard(String uid) {
		Connection con=null;
		PreparedStatement pstmtUp=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="";
		TeamBoard board=null;
		
		try {
			con = getConnection();
			
			sql = "select * from user where u_id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, uid);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				board = new TeamBoard();
				board.setU_id(rs.getString(1));
				board.setU_pwd(rs.getString(2));
				board.setU_name(rs.getString(3));
				board.setU_email(rs.getString(4));
				board.setU_phone(rs.getInt(5));
				board.setU_birth(rs.getInt(6));
				board.setU_sex(rs.getInt(7));
				board.setU_manager(rs.getInt(8));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return board;
	}
	
	public int idDelete(String u_id, String u_pwd) {
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="";
		int result=-1;
		String pwd="";
		
		try {
			con = getConnection();
			sql = "select u_pwd from user_tbl where u_id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, u_id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				pwd = rs.getString(1);
				
				if (!pwd.equals(u_pwd)) {
					result=0;
				}else {
					sql="delete user_tbl where u_id=?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, u_id);
					pstmt.executeUpdate();
					result=1;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return result;
	}
	
	public int editID(TeamBoard board) {
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="";
		int re=-1;
		String pwd="";
		
		try {
			con = getConnection();
			sql = "select u_pwd from user_tbl where u_id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,board.getU_id());
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				pwd = rs.getString(1);
				
				if(!pwd.equals(board.getU_pwd())) {
					re=0;
				}else {
					sql="update user_tbl set u_name=?, u_email=?, u_phone=? where u_id=?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, HanConv.tokor(board.getU_name()));
					pstmt.setString(2, board.getU_email());
					pstmt.setInt(3, board.getU_phone());
					pstmt.setString(4, board.getU_id());
					pstmt.executeUpdate();
					re=1;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}
}
