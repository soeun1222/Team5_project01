package main_bucket;

public class Comment {
	private int comm_num;
	private String comm_table;
	private String comm_content;
	private int comm_ref;
	private int comm_step;
	private int comm_level;
	private int table_num;
	private String user_tbl_u_id;
	
	
	
	public int getComm_num() {
		return comm_num;
	}
	public void setComm_num(int comm_num) {
		this.comm_num = comm_num;
	}
	public String getComm_table() {
		return comm_table;
	}
	public void setComm_table(String comm_table) {
		this.comm_table = comm_table;
	}
	public String getComm_content() {
		return comm_content;
	}
	public void setComm_content(String comm_content) {
		this.comm_content = comm_content;
	}
	public int getComm_ref() {
		return comm_ref;
	}
	public void setComm_ref(int comm_ref) {
		this.comm_ref = comm_ref;
	}
	public int getComm_step() {
		return comm_step;
	}
	public void setComm_step(int comm_step) {
		this.comm_step = comm_step;
	}
	public int getComm_level() {
		return comm_level;
	}
	public void setComm_level(int comm_level) {
		this.comm_level = comm_level;
	}
	public int getTable_num() {
		return table_num;
	}
	public void setTable_num(int table_num) {
		this.table_num = table_num;
	}
	public String getUser_tbl_u_id() {
		return user_tbl_u_id;
	}
	public void setUser_tbl_u_id(String user_tbl_u_id) {
		this.user_tbl_u_id = user_tbl_u_id;
	}


	
}
