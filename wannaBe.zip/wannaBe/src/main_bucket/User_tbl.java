package main_bucket;

public class User_tbl {
	private String u_id;
	private String u_pwd;
	private String u_name;
	private String u_email;
	private int u_phone;
	private int u_;
	
}
